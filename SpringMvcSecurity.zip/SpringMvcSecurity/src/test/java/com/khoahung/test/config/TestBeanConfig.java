package com.khoahung.test.config;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = "com.khoahung")
public class TestBeanConfig {

}